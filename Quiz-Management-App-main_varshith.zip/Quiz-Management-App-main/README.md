# Quiz Management App

A simple and interactive quiz application built using HTML, CSS, and JavaScript.

## Features

- Multiple quiz categories
- HTML, CSS, JavaScript, Python, and SQL questions
- Choose the number of questions
- Choose the time limit
- Randomized questions
- Randomized answer options
- Countdown timer
- Automatic submission when time ends
- Score and percentage calculation
- Restart quiz option
- Responsive design

## Technologies Used

- HTML
- CSS
- JavaScript

## How to Run

1. Download or clone the repository.
2. Open the project folder.
3. Open `index.html` in a web browser.
4. Select a category, number of questions, and time limit.
5. Click **Start Quiz**.

## Project Structure

```text
Quiz-Management-App/
│
├── index.html
├── style.css
├── script.js
└── README.md