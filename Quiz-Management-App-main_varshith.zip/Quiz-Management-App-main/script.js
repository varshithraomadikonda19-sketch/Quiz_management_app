// ==========================================
// QUESTION BANK - 100 QUESTIONS
// ==========================================

const questions = [

    // ======================================
    // HTML - 20 QUESTIONS
    // ======================================

    {
        category: "HTML",
        question: "What does HTML stand for?",
        answers: [
            { text: "Hyper Text Markup Language", correct: true },
            { text: "High Text Machine Language", correct: false },
            { text: "Hyperlink Text Management Language", correct: false },
            { text: "Home Tool Markup Language", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag creates a hyperlink?",
        answers: [
            { text: "<link>", correct: false },
            { text: "<a>", correct: true },
            { text: "<href>", correct: false },
            { text: "<url>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag displays an image?",
        answers: [
            { text: "<image>", correct: false },
            { text: "<img>", correct: true },
            { text: "<picture>", correct: false },
            { text: "<src>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag creates the largest heading?",
        answers: [
            { text: "<h6>", correct: false },
            { text: "<h1>", correct: true },
            { text: "<head>", correct: false },
            { text: "<heading>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag creates an unordered list?",
        answers: [
            { text: "<ol>", correct: false },
            { text: "<list>", correct: false },
            { text: "<ul>", correct: true },
            { text: "<li>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag creates a paragraph?",
        answers: [
            { text: "<paragraph>", correct: false },
            { text: "<p>", correct: true },
            { text: "<para>", correct: false },
            { text: "<text>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which attribute provides alternative text for an image?",
        answers: [
            { text: "src", correct: false },
            { text: "href", correct: false },
            { text: "alt", correct: true },
            { text: "title", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag creates a table row?",
        answers: [
            { text: "<td>", correct: false },
            { text: "<tr>", correct: true },
            { text: "<row>", correct: false },
            { text: "<table-row>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag creates a table cell?",
        answers: [
            { text: "<td>", correct: true },
            { text: "<tr>", correct: false },
            { text: "<cell>", correct: false },
            { text: "<tc>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag creates an ordered list?",
        answers: [
            { text: "<ul>", correct: false },
            { text: "<ol>", correct: true },
            { text: "<li>", correct: false },
            { text: "<list>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag defines a list item?",
        answers: [
            { text: "<item>", correct: false },
            { text: "<li>", correct: true },
            { text: "<list>", correct: false },
            { text: "<ul>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag contains metadata about an HTML document?",
        answers: [
            { text: "<body>", correct: false },
            { text: "<head>", correct: true },
            { text: "<meta-data>", correct: false },
            { text: "<info>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag contains the visible page content?",
        answers: [
            { text: "<head>", correct: false },
            { text: "<body>", correct: true },
            { text: "<main-page>", correct: false },
            { text: "<content>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag creates a line break?",
        answers: [
            { text: "<break>", correct: false },
            { text: "<br>", correct: true },
            { text: "<lb>", correct: false },
            { text: "<line>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag is used to create a form?",
        answers: [
            { text: "<input>", correct: false },
            { text: "<form>", correct: true },
            { text: "<fieldset>", correct: false },
            { text: "<data>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag creates a button?",
        answers: [
            { text: "<btn>", correct: false },
            { text: "<button>", correct: true },
            { text: "<click>", correct: false },
            { text: "<input-button>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which attribute specifies the destination of a hyperlink?",
        answers: [
            { text: "src", correct: false },
            { text: "href", correct: true },
            { text: "link", correct: false },
            { text: "url", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag is used to define emphasized text?",
        answers: [
            { text: "<em>", correct: true },
            { text: "<strong>", correct: false },
            { text: "<italic>", correct: false },
            { text: "<i-text>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which tag represents strong importance?",
        answers: [
            { text: "<bold>", correct: false },
            { text: "<strong>", correct: true },
            { text: "<important>", correct: false },
            { text: "<b-important>", correct: false }
        ]
    },

    {
        category: "HTML",
        question: "Which declaration defines an HTML5 document?",
        answers: [
            { text: "<html5>", correct: false },
            { text: "<!DOCTYPE html>", correct: true },
            { text: "<DOCTYPE5>", correct: false },
            { text: "<HTML5>", correct: false }
        ]
    },


    // ======================================
    // CSS - 20 QUESTIONS
    // ======================================

    {
        category: "CSS",
        question: "What does CSS stand for?",
        answers: [
            { text: "Cascading Style Sheets", correct: true },
            { text: "Computer Style System", correct: false },
            { text: "Creative Style Sheets", correct: false },
            { text: "Colorful Style System", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property changes text color?",
        answers: [
            { text: "font-color", correct: false },
            { text: "text-color", correct: false },
            { text: "color", correct: true },
            { text: "foreground", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property changes background color?",
        answers: [
            { text: "background-color", correct: true },
            { text: "bg-color", correct: false },
            { text: "color-background", correct: false },
            { text: "background-style", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property changes font size?",
        answers: [
            { text: "font-style", correct: false },
            { text: "font-size", correct: true },
            { text: "text-size", correct: false },
            { text: "size", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property adds space inside an element?",
        answers: [
            { text: "margin", correct: false },
            { text: "padding", correct: true },
            { text: "spacing", correct: false },
            { text: "inside-space", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property adds space outside an element?",
        answers: [
            { text: "padding", correct: false },
            { text: "margin", correct: true },
            { text: "spacing", correct: false },
            { text: "outside-space", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which display value creates a flex container?",
        answers: [
            { text: "block", correct: false },
            { text: "inline", correct: false },
            { text: "flex", correct: true },
            { text: "container", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which symbol selects an element by ID?",
        answers: [
            { text: ".", correct: false },
            { text: "#", correct: true },
            { text: "*", correct: false },
            { text: "$", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which symbol selects a class?",
        answers: [
            { text: "#", correct: false },
            { text: ".", correct: true },
            { text: "*", correct: false },
            { text: "@", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property makes text bold?",
        answers: [
            { text: "font-weight", correct: true },
            { text: "text-bold", correct: false },
            { text: "font-bold", correct: false },
            { text: "weight", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property aligns text?",
        answers: [
            { text: "text-align", correct: true },
            { text: "align-text", correct: false },
            { text: "font-align", correct: false },
            { text: "alignment", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property changes the width of an element?",
        answers: [
            { text: "size", correct: false },
            { text: "width", correct: true },
            { text: "element-width", correct: false },
            { text: "length", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property changes the height of an element?",
        answers: [
            { text: "height", correct: true },
            { text: "size-height", correct: false },
            { text: "length", correct: false },
            { text: "element-height-size", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property creates rounded corners?",
        answers: [
            { text: "corner-radius", correct: false },
            { text: "border-radius", correct: true },
            { text: "radius", correct: false },
            { text: "round-border", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property adds a shadow around an element?",
        answers: [
            { text: "shadow", correct: false },
            { text: "box-shadow", correct: true },
            { text: "element-shadow", correct: false },
            { text: "border-shadow", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property changes the font family?",
        answers: [
            { text: "font-family", correct: true },
            { text: "font-type", correct: false },
            { text: "text-family", correct: false },
            { text: "family", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property controls transparency?",
        answers: [
            { text: "opacity", correct: true },
            { text: "transparent", correct: false },
            { text: "visibility", correct: false },
            { text: "alpha", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property controls the position of an element?",
        answers: [
            { text: "position", correct: true },
            { text: "place", correct: false },
            { text: "location", correct: false },
            { text: "element-position", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which CSS property controls the stacking order?",
        answers: [
            { text: "stack", correct: false },
            { text: "z-index", correct: true },
            { text: "layer", correct: false },
            { text: "order-index", correct: false }
        ]
    },

    {
        category: "CSS",
        question: "Which property changes the cursor appearance?",
        answers: [
            { text: "mouse", correct: false },
            { text: "cursor", correct: true },
            { text: "pointer-style", correct: false },
            { text: "mouse-pointer", correct: false }
        ]
    },


    // ======================================
    // JAVASCRIPT - 20 QUESTIONS
    // ======================================

    {
        category: "JavaScript",
        question: "Which keyword declares a variable?",
        answers: [
            { text: "let", correct: true },
            { text: "variable", correct: false },
            { text: "int", correct: false },
            { text: "define", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which keyword declares a constant?",
        answers: [
            { text: "constant", correct: false },
            { text: "const", correct: true },
            { text: "fixed", correct: false },
            { text: "static", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which method adds an item to the end of an array?",
        answers: [
            { text: "add()", correct: false },
            { text: "push()", correct: true },
            { text: "insert()", correct: false },
            { text: "append()", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which method removes the last array element?",
        answers: [
            { text: "remove()", correct: false },
            { text: "delete()", correct: false },
            { text: "pop()", correct: true },
            { text: "last()", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which operator checks strict equality?",
        answers: [
            { text: "=", correct: false },
            { text: "==", correct: false },
            { text: "===", correct: true },
            { text: "!=", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which symbol starts a single-line comment?",
        answers: [
            { text: "#", correct: false },
            { text: "//", correct: true },
            { text: "<!--", correct: false },
            { text: "/*", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which function displays a message in the console?",
        answers: [
            { text: "console.log()", correct: true },
            { text: "print()", correct: false },
            { text: "display()", correct: false },
            { text: "message()", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which method converts JSON text into an object?",
        answers: [
            { text: "JSON.parse()", correct: true },
            { text: "JSON.convert()", correct: false },
            { text: "JSON.object()", correct: false },
            { text: "JSON.read()", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which method converts an object into JSON text?",
        answers: [
            { text: "JSON.convert()", correct: false },
            { text: "JSON.stringify()", correct: true },
            { text: "JSON.object()", correct: false },
            { text: "JSON.text()", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which method selects an element by ID?",
        answers: [
            { text: "document.getElementById()", correct: true },
            { text: "document.getElement()", correct: false },
            { text: "document.selectId()", correct: false },
            { text: "document.findId()", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which keyword is used for a function?",
        answers: [
            { text: "function", correct: true },
            { text: "def", correct: false },
            { text: "fun", correct: false },
            { text: "method", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which array method creates a new array by transforming elements?",
        answers: [
            { text: "map()", correct: true },
            { text: "change()", correct: false },
            { text: "transform()", correct: false },
            { text: "modify()", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which array method filters elements?",
        answers: [
            { text: "filter()", correct: true },
            { text: "select()", correct: false },
            { text: "choose()", correct: false },
            { text: "findAll()", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which keyword stops a loop?",
        answers: [
            { text: "stop", correct: false },
            { text: "exit", correct: false },
            { text: "break", correct: true },
            { text: "end", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which keyword skips the current loop iteration?",
        answers: [
            { text: "skip", correct: false },
            { text: "continue", correct: true },
            { text: "next", correct: false },
            { text: "pass", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which value represents absence of a value?",
        answers: [
            { text: "empty", correct: false },
            { text: "null", correct: true },
            { text: "void-value", correct: false },
            { text: "none", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which operator is used for logical AND?",
        answers: [
            { text: "||", correct: false },
            { text: "&&", correct: true },
            { text: "AND", correct: false },
            { text: "&", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which operator is used for logical OR?",
        answers: [
            { text: "&&", correct: false },
            { text: "||", correct: true },
            { text: "OR", correct: false },
            { text: "|", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which statement is used for decision making?",
        answers: [
            { text: "if", correct: true },
            { text: "check", correct: false },
            { text: "when", correct: false },
            { text: "condition", correct: false }
        ]
    },

    {
        category: "JavaScript",
        question: "Which keyword creates a class?",
        answers: [
            { text: "object", correct: false },
            { text: "class", correct: true },
            { text: "struct", correct: false },
            { text: "type", correct: false }
        ]
    },


    // ======================================
    // PYTHON - 20 QUESTIONS
    // ======================================

    {
        category: "Python",
        question: "Which function displays output in Python?",
        answers: [
            { text: "display()", correct: false },
            { text: "print()", correct: true },
            { text: "output()", correct: false },
            { text: "show()", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which symbol starts a comment?",
        answers: [
            { text: "//", correct: false },
            { text: "#", correct: true },
            { text: "/*", correct: false },
            { text: "<!--", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which data type stores an ordered collection that can be changed?",
        answers: [
            { text: "tuple", correct: false },
            { text: "list", correct: true },
            { text: "set", correct: false },
            { text: "dictionary", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which keyword defines a function?",
        answers: [
            { text: "function", correct: false },
            { text: "define", correct: false },
            { text: "def", correct: true },
            { text: "fun", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which function returns the length of a list?",
        answers: [
            { text: "length()", correct: false },
            { text: "size()", correct: false },
            { text: "len()", correct: true },
            { text: "count()", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which keyword is used to loop through a sequence?",
        answers: [
            { text: "loop", correct: false },
            { text: "for", correct: true },
            { text: "repeat", correct: false },
            { text: "iterate", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which data type stores key-value pairs?",
        answers: [
            { text: "list", correct: false },
            { text: "tuple", correct: false },
            { text: "dictionary", correct: true },
            { text: "set", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which function gets input from the user?",
        answers: [
            { text: "get()", correct: false },
            { text: "read()", correct: false },
            { text: "input()", correct: true },
            { text: "scan()", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which keyword is used for a condition?",
        answers: [
            { text: "if", correct: true },
            { text: "check", correct: false },
            { text: "condition", correct: false },
            { text: "when", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which keyword represents another condition?",
        answers: [
            { text: "otherwise", correct: false },
            { text: "else", correct: true },
            { text: "other", correct: false },
            { text: "default", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which keyword handles exceptions?",
        answers: [
            { text: "catch", correct: false },
            { text: "try", correct: true },
            { text: "handle", correct: false },
            { text: "exception", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which collection does not allow duplicate values?",
        answers: [
            { text: "list", correct: false },
            { text: "tuple", correct: false },
            { text: "set", correct: true },
            { text: "dictionary", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which function converts a value to an integer?",
        answers: [
            { text: "integer()", correct: false },
            { text: "int()", correct: true },
            { text: "number()", correct: false },
            { text: "convert()", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which function converts a value to a string?",
        answers: [
            { text: "string()", correct: false },
            { text: "str()", correct: true },
            { text: "text()", correct: false },
            { text: "convert()", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which operator is used for exponentiation?",
        answers: [
            { text: "^", correct: false },
            { text: "**", correct: true },
            { text: "//", correct: false },
            { text: "^^", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which operator performs floor division?",
        answers: [
            { text: "/", correct: false },
            { text: "//", correct: true },
            { text: "%", correct: false },
            { text: "**", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which keyword is used to create a class?",
        answers: [
            { text: "class", correct: true },
            { text: "object", correct: false },
            { text: "struct", correct: false },
            { text: "type", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which value represents no value in Python?",
        answers: [
            { text: "null", correct: false },
            { text: "None", correct: true },
            { text: "empty", correct: false },
            { text: "void", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which function returns the largest value?",
        answers: [
            { text: "largest()", correct: false },
            { text: "max()", correct: true },
            { text: "big()", correct: false },
            { text: "high()", correct: false }
        ]
    },

    {
        category: "Python",
        question: "Which function returns the smallest value?",
        answers: [
            { text: "smallest()", correct: false },
            { text: "min()", correct: true },
            { text: "low()", correct: false },
            { text: "small()", correct: false }
        ]
    },


    // ======================================
    // SQL - 20 QUESTIONS
    // ======================================

    {
        category: "SQL",
        question: "What does SQL stand for?",
        answers: [
            { text: "Structured Query Language", correct: true },
            { text: "Simple Query Language", correct: false },
            { text: "System Query Logic", correct: false },
            { text: "Structured Question Language", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which command retrieves data?",
        answers: [
            { text: "GET", correct: false },
            { text: "SELECT", correct: true },
            { text: "FETCH", correct: false },
            { text: "READ", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which command adds new records?",
        answers: [
            { text: "ADD", correct: false },
            { text: "INSERT", correct: true },
            { text: "CREATE", correct: false },
            { text: "APPEND", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which command modifies existing records?",
        answers: [
            { text: "CHANGE", correct: false },
            { text: "MODIFY", correct: false },
            { text: "UPDATE", correct: true },
            { text: "ALTER", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which command removes records?",
        answers: [
            { text: "REMOVE", correct: false },
            { text: "DELETE", correct: true },
            { text: "DROP", correct: false },
            { text: "CLEAR", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which clause filters rows?",
        answers: [
            { text: "FILTER", correct: false },
            { text: "WHERE", correct: true },
            { text: "HAVING", correct: false },
            { text: "LIMIT", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which keyword removes duplicate results?",
        answers: [
            { text: "UNIQUE", correct: false },
            { text: "DISTINCT", correct: true },
            { text: "DIFFERENT", correct: false },
            { text: "ONLY", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which clause sorts query results?",
        answers: [
            { text: "SORT BY", correct: false },
            { text: "ORDER BY", correct: true },
            { text: "GROUP BY", correct: false },
            { text: "ARRANGE BY", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which clause groups rows?",
        answers: [
            { text: "GROUP BY", correct: true },
            { text: "ORDER BY", correct: false },
            { text: "SORT BY", correct: false },
            { text: "COLLECT BY", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which function counts rows?",
        answers: [
            { text: "COUNT()", correct: true },
            { text: "NUMBER()", correct: false },
            { text: "TOTAL()", correct: false },
            { text: "ROWS()", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which function calculates the average?",
        answers: [
            { text: "MEAN()", correct: false },
            { text: "AVG()", correct: true },
            { text: "AVERAGE()", correct: false },
            { text: "MID()", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which function returns the highest value?",
        answers: [
            { text: "HIGH()", correct: false },
            { text: "MAX()", correct: true },
            { text: "TOP()", correct: false },
            { text: "UP()", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which function returns the lowest value?",
        answers: [
            { text: "LOW()", correct: false },
            { text: "MIN()", correct: true },
            { text: "BOTTOM()", correct: false },
            { text: "LOWEST()", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which command creates a table?",
        answers: [
            { text: "MAKE TABLE", correct: false },
            { text: "CREATE TABLE", correct: true },
            { text: "NEW TABLE", correct: false },
            { text: "BUILD TABLE", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which command deletes a table?",
        answers: [
            { text: "DELETE TABLE", correct: false },
            { text: "DROP TABLE", correct: true },
            { text: "REMOVE TABLE", correct: false },
            { text: "CLEAR TABLE", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which keyword combines rows from two tables?",
        answers: [
            { text: "COMBINE", correct: false },
            { text: "JOIN", correct: true },
            { text: "MERGE", correct: false },
            { text: "CONNECT", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which JOIN returns matching rows from both tables?",
        answers: [
            { text: "INNER JOIN", correct: true },
            { text: "OUTER JOIN", correct: false },
            { text: "MATCH JOIN", correct: false },
            { text: "COMMON JOIN", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which constraint uniquely identifies a row?",
        answers: [
            { text: "UNIQUE KEY", correct: false },
            { text: "PRIMARY KEY", correct: true },
            { text: "IDENTITY", correct: false },
            { text: "ROW KEY", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which constraint prevents NULL values?",
        answers: [
            { text: "NOT NULL", correct: true },
            { text: "NO NULL", correct: false },
            { text: "REQUIRED", correct: false },
            { text: "NULL FALSE", correct: false }
        ]
    },

    {
        category: "SQL",
        question: "Which keyword gives a column an alias?",
        answers: [
            { text: "AS", correct: true },
            { text: "ALIAS", correct: false },
            { text: "NAME", correct: false },
            { text: "RENAME", correct: false }
        ]
    }

];


// ==========================================
// VARIABLES
// ==========================================

let selectedCategory = "All";
let quizQuestions = [];
let currentQuestionIndex = 0;
let score = 0;

let timeLeft = 0;
let timer = null;


// ==========================================
// HTML ELEMENTS
// ==========================================

const startScreen =
    document.getElementById("start-screen");

const quizBox =
    document.getElementById("quiz-box");

const resultBox =
    document.getElementById("result-box");

const startButton =
    document.getElementById("start-btn");

const nextButton =
    document.getElementById("next-btn");

const restartButton =
    document.getElementById("restart-btn");

const questionElement =
    document.getElementById("question");

const answerButtons =
    document.getElementById("answer-buttons");

const questionNumber =
    document.getElementById("question-number");

const scoreElement =
    document.getElementById("score");

const categoryName =
    document.getElementById("category-name");

const resultElement =
    document.getElementById("result");

const resultMessage =
    document.getElementById("result-message");

const timerElement =
    document.getElementById("timer");

const categoryButtons =
    document.querySelectorAll(".category-btn");

const questionCount =
    document.getElementById("question-count");

const timeLimit =
    document.getElementById("time-limit");


// ==========================================
// CATEGORY SELECTION
// ==========================================

categoryButtons.forEach(function (button) {

    button.addEventListener("click", function () {

        categoryButtons.forEach(function (btn) {
            btn.classList.remove("selected");
        });

        button.classList.add("selected");

        selectedCategory =
            button.dataset.category;

    });

});


// ==========================================
// START QUIZ
// ==========================================

startButton.addEventListener(
    "click",
    startQuiz
);


function startQuiz() {

    currentQuestionIndex = 0;

    score = 0;


    const selectedQuestionCount =
        Number(questionCount.value);

    const selectedTime =
        Number(timeLimit.value);


    let filteredQuestions;


    if (selectedCategory === "All") {

        filteredQuestions =
            [...questions];

    } else {

        filteredQuestions =
            questions.filter(function (question) {

                return question.category ===
                    selectedCategory;

            });

    }


    // Shuffle questions

    filteredQuestions.sort(function () {

        return Math.random() - 0.5;

    });


    // Get requested number of questions

    quizQuestions =
        filteredQuestions.slice(
            0,
            selectedQuestionCount
        );


    // Set timer

    timeLeft =
        selectedTime * 60;


    updateTimer();


    clearInterval(timer);


    timer = setInterval(
        countdown,
        1000
    );


    scoreElement.innerText =
        "Score: 0";


    startScreen.classList.add("hide");

    quizBox.classList.remove("hide");

    resultBox.classList.add("hide");


    showQuestion();
}


// ==========================================
// TIMER
// ==========================================

function countdown() {

    timeLeft--;

    updateTimer();


    if (timeLeft <= 0) {

        clearInterval(timer);

        showResult();

    }
}


// ==========================================
// UPDATE TIMER
// ==========================================

function updateTimer() {

    const minutes =
        Math.floor(timeLeft / 60);

    const seconds =
        timeLeft % 60;


    const formattedSeconds =
        seconds < 10
            ? "0" + seconds
            : seconds;


    timerElement.innerText =
        "Time: " +
        minutes +
        ":" +
        formattedSeconds;
}


// ==========================================
// SHOW QUESTION
// ==========================================

function showQuestion() {

    resetState();


    const currentQuestion =
        quizQuestions[currentQuestionIndex];


    questionNumber.innerText =
        "Question " +
        (currentQuestionIndex + 1) +
        " of " +
        quizQuestions.length;


    categoryName.innerText =
        currentQuestion.category;


    questionElement.innerText =
        currentQuestion.question;


    let shuffledAnswers =
        [...currentQuestion.answers];


    shuffledAnswers.sort(function () {

        return Math.random() - 0.5;

    });


    shuffledAnswers.forEach(function (answer) {

        const button =
            document.createElement("button");


        button.innerText =
            answer.text;


        button.classList.add(
            "answer-btn"
        );


        if (answer.correct) {

            button.dataset.correct =
                "true";

        }


        button.addEventListener(
            "click",
            selectAnswer
        );


        answerButtons.appendChild(
            button
        );

    });

}


// ==========================================
// RESET ANSWERS
// ==========================================

function resetState() {

    nextButton.style.display =
        "none";


    while (
        answerButtons.firstChild
    ) {

        answerButtons.removeChild(
            answerButtons.firstChild
        );

    }
}


// ==========================================
// SELECT ANSWER
// ==========================================

function selectAnswer(event) {

    const selectedButton =
        event.target;


    const isCorrect =
        selectedButton.dataset.correct ===
        "true";


    if (isCorrect) {

        selectedButton.classList.add(
            "correct"
        );

        score++;

        scoreElement.innerText =
            "Score: " + score;

    } else {

        selectedButton.classList.add(
            "wrong"
        );

    }


    Array.from(
        answerButtons.children
    ).forEach(function (button) {

        if (
            button.dataset.correct ===
            "true"
        ) {

            button.classList.add(
                "correct"
            );

        }

        button.disabled = true;

    });


    nextButton.style.display =
        "block";
}


// ==========================================
// NEXT QUESTION
// ==========================================

nextButton.addEventListener(
    "click",
    function () {

        currentQuestionIndex++;


        if (
            currentQuestionIndex <
            quizQuestions.length
        ) {

            showQuestion();

        } else {

            showResult();

        }

    }
);


// ==========================================
// SHOW RESULT
// ==========================================

function showResult() {

    clearInterval(timer);


    quizBox.classList.add("hide");

    resultBox.classList.remove("hide");


    const percentage =
        Math.round(
            (score /
                quizQuestions.length) *
            100
        );


    resultElement.innerText =
        "Score: " +
        score +
        " / " +
        quizQuestions.length +
        " (" +
        percentage +
        "%)";


    if (percentage >= 80) {

        resultMessage.innerText =
            "Excellent! You have a strong understanding of this topic.";

    } else if (percentage >= 60) {

        resultMessage.innerText =
            "Good job! Keep practicing to improve your score.";

    } else {

        resultMessage.innerText =
            "Keep practicing! Review the topics and try again.";

    }
}


// ==========================================
// RESTART QUIZ
// ==========================================

restartButton.addEventListener(
    "click",
    function () {

        clearInterval(timer);

        resultBox.classList.add("hide");

        startScreen.classList.remove("hide");

    }
);